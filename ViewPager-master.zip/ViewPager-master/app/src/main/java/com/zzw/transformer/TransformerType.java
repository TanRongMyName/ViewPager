package com.zzw.transformer;

/**
 * Created by zzw on 2017/3/22.
 */

public interface TransformerType {
    static final String TYPE="TRANSFORMERTYPE";
    static final int NORMAL=0;
    static final int SCALE=1;
    static final int ROTATE=2;
}
